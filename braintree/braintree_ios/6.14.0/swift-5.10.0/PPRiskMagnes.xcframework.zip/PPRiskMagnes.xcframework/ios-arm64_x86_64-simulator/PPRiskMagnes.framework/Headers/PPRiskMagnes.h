//
//  PPRiskMagnes.h
//  PPRiskMagnes
//
//  Created by James Zhou on 7/31/17.
//  Copyright © 2017 PayPal Risk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MagnesCryptoUtil.h"
#import "MagnesSystemConfigUtils.h"
//! Project version number for PPRiskMagnes.
FOUNDATION_EXPORT double PPRiskMagnesVersionNumber;

//! Project version string for PPRiskMagnes.
FOUNDATION_EXPORT const unsigned char PPRiskMagnesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PPRiskMagnes/PublicHeader.h>
